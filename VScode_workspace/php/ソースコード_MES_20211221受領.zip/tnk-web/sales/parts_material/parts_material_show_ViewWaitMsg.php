<?php
//////////////////////////////////////////////////////////////////////////////
// 部品売上げの材料費(購入費)の照会 処理中のメッセージ表示(Ajax) MVC View部 //
// Copyright (C) 2006-2006 Kazuhiro.Kobayashi tnksys@nitto-kohki.co.jp      //
// Changed history                                                          //
// 2006/02/19 Created   parts_material_show_ViewWaitMsg.php                 //
//////////////////////////////////////////////////////////////////////////////
?>
        <br><br>
        <table width='100%' border='0'>
            <tr>
            <td align='center' style='font-size:20pt; font-weight:bold;'>
            処理中です。お待ち下さい。<br>
            <img src='/img/tnk-turbine.gif' width='68' height='72'>
            </td>
            </tr>
        </table>
