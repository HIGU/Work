<?php
//////////////////////////////////////////////////////////////////////////////
// ������ư���������ƥ�θ��߱�ž���������ޥå�ɽ��(�쥤������)Include file //
// Copyright (C) 2004-2004 Kazuhiro.Kobayashi tnksys@nitto-kohki.co.jp      //
//               Designed  Norihisa.ooya                                    //
// Changed history                                                          //
// 2004/09/23 Created  equip_work_map4List.php (include file)               //
// 2006/03/09 �쥤�������ѹ�(1365��1366��1367)�ɲ�                          //
//////////////////////////////////////////////////////////////////////////////
?>
<table width='100%' height='75%' cellspacing='3' cellpadding='0' border='2' bgcolor='#f7f7f7' bordercolor='#1a6699'>
    <tr>
        <td width='10' rowspan='3'></td>
        <td width='70' height='30' rowspan='3' bgcolor='#f0f0f0'>�����֤���</td>
        <td height='30' bgcolor='#f0f0f0'><center><b>�ɥ�</b></center></td>
        <td height='30' colspan='4'></td>
        <td height='30' bgcolor='#f0f0f0' nowrap><b>�� ������</b></td>
        <td height='30' colspan='4'></td>
        <td height='30' bgcolor='#f0f0f0'><b>��̳�� ��<b></td>
    </tr>
    <tr>
        <td width='60' height='40' rowspan='2'></td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1353') ?>
            <input type='image' alt='����No1353 BNC-3' height='65' width='65' border='0' src='../img/1353.jpg' onClick='win_open("../img/1353L.jpg","����No1353 BNC-3")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1352') ?>
            <input type='image' alt='����No1352 BNC-2' height='65' width='65' border='0' src='../img/1352.jpg' onClick='win_open("../img/1352L.jpg","����No1352 BNC-2")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1351') ?>
            <input type='image' alt='����No1351 BNC-1' height='65' width='65' border='0' src='../img/1351.jpg' onClick='win_open("../img/1351L.jpg","����No1351 BNC-1")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1361') ?>
            <input type='image' alt='����No1361 BND-1' height='65' width='65' border='0' src='../img/1361.jpg' onClick='win_open("../img/1361L.jpg","����No1361 BND-1")'>
        </td>
        <td rowspan='2' bgcolor='#ffffff' nowrap valign='center' align='center'>
            <?php mac_state_view('1364') ?>
            <input type='image' alt='����No1364 BND-4' height='65' width='65' border='0' src='../img/1364.jpg' onClick='win_open("../img/1364L.jpg","����No1364 BND-4")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1347') ?>
            <input type='image' alt='����No1347 BNF-1' height='65' width='65' border='0' src='../img/1347.jpg' onClick='win_open("../img/1347L.jpg","����No1347 BNF-1")'>
        </td>
        <td rowspan='2' bgcolor='#ffffff' nowrap valign='center' align='center'>
            <?php mac_state_view('1348') ?>
            <input type='image' alt='����No1348 BNF-2' height='65' width='65' border='0' src='../img/1348.jpg' onClick='win_open("../img/1348L.jpg","����No1348 BNF-2")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1363') ?>
            <input type='image' alt='����No1363 BND-3' height='65' width='65' border='0' src='../img/1363.jpg' onClick='win_open("../img/1363L.jpg","����No1363 BND-3")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1362') ?>
            <input type='image' alt='����No1362 BND-2' height='65' width='65' border='0' src='../img/1362.jpg' onClick='win_open("../img/1362L.jpg","����No1362 BND-2")'>
        </td>
        <td width='30' height='30'></td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1367') ?>
            <input type='image' alt='����No1367 BA20' height='65' width='65' border='0' src='../img/1367.jpg' onClick='win_open("../img/1367L.jpg","����No1367 ���ގ�-1")'>
        </td>
    </tr>
    <tr>
        <td bgcolor='#ffffff' height='120' nowrap valign='center' align='center'>
            <?php mac_state_view('1307') ?>
            <input type='image' alt='����No1307 NC-7' height='65' width='65' border='0' src='../img/1307.jpg' onClick='win_open("../img/1307L.jpg","����No1307 NC-7")'>
        </td>
    </tr>
    <tr>
        <td width='10' height='100' bgcolor='#f0f0f0'><b>�ɥ�</b></td>
    </tr>
    <tr>
        <td width='10' rowspan='3'></td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1345') ?>
            <input type='image' alt='����No1345 LD-4' height='65' width='65' border='0' src='../img/1345.jpg' onClick='win_open("../img/1345L.jpg","����No1345 LD-4")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1341') ?>
            <input type='image' alt='����No1341 KNC-1' height='65' width='65' border='0' src='../img/1341.jpg' onClick='win_open("../img/1341L.jpg","����No1341 KNC-1")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1342') ?>
            <input type='image' alt='����No1342 LD-1' height='65' width='65' border='0' src='../img/1342.jpg' onClick='win_open("../img/1342L.jpg","����No1342 LD-1")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1343') ?>
            <input type='image' alt='����No1343 LD-2' height='65' width='65' border='0' src='../img/1343.jpg' onClick='win_open("../img/1343L.jpg","����No1343 LD-2")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1344') ?>
            <input type='image' alt='����No1344 LD-3' height='65' width='65' border='0' src='../img/1344.jpg' onClick='win_open("../img/1344L.jpg","����No1344 LD-3")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1346') ?>
            <input type='image' alt='����No1346 BNE-1' height='65' width='65' border='0' src='../img/1346.jpg' onClick='win_open("../img/1346L.jpg","����No1346 BNE-1")'>
        </td>
        
        <td colspan='4'></td>
        
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1349') ?>
            <input type='image' alt='����No1349 WTS-1' height='65' width='65' border='0' src='../img/1349.jpg' onClick='win_open("../img/1349L.jpg","����No1349 WTS-1")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1365') ?>
            <input type='image' alt='����No1365 WT-100-1' height='65' width='65' border='0' src='../img/1365.jpg' onClick='win_open("../img/1365L.jpg","����No1365 WT-1")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1366') ?>
            <input type='image' alt='����No1366 WT-100-2' height='65' width='65' border='0' src='../img/1366.jpg' onClick='win_open("../img/1366L.jpg","����No1366 WT-2")'>
        </td>
    </tr>   
    <tr>
        <td height='80' colspan='4' bgcolor='#f0f0f0'><center>������</center></td>
    </tr>
    <tr>
        <td height='30' colspan='5'></td>
        <td height='30' bgcolor='#f0f0f0'><center><b>������ ��</b></center></td>
    </tr>
</table>
