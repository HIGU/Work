<?php
//////////////////////////////////////////////////////////////////////////////
// ������ư���������ƥ�θ��߱�ž���������ޥå�ɽ��(�쥤������)Include file //
// Copyright (C) 2021-2021 Norihisa.ooya norihisa_ooya@nitto-kohki.co.jp    //
// Changed history                                                          //
// 2021/06/22 Created  equip_work_map7cList.php (include file)              //
//////////////////////////////////////////////////////////////////////////////
?>
<table width='100%' height='75%' cellspacing='3' cellpadding='0' border='2' bgcolor='#f7f7f7' bordercolor='#1a6699'>
    <tr>
        <td rowspan='3'></td>
        <!--
        <td width='70' height='30'></td>
        <td width='70' height='30' rowspan='3' bgcolor='#f0f0f0'>2���ù�</td>
        <td height='30' bgcolor='#f0f0f0'><center><b>�ɥ�</b></center></td>
        <td height='30' colspan='4'></td>
        <td height='30' bgcolor='#f0f0f0' nowrap><b>�� ������</b></td>
        -->
        <td hcolspan='16'></td>
        <td rowspan='3'></td>
        <!--
        <td height='30' bgcolor='#f0f0f0'><b>��̳�� ��<b></td>
        -->
    </tr>
    <tr>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1230') ?>
            <input type='image' alt='����No1230 B0385L' height='65' width='65' border='0' src='../img/1230.jpg' onClick='win_open("../img/1230L.jpg","����No1230 B0385L")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1233') ?>
            <input type='image' alt='����No1233 NZX-1' height='65' width='65' border='0' src='../img/1233.jpg' onClick='win_open("../img/1233L.jpg","����No1233 NZX-1")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1234') ?>
            <input type='image' alt='����No1234 NZX-2' height='65' width='65' border='0' src='../img/1234.jpg' onClick='win_open("../img/1234L.jpg","����No1234 NZX-2")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1235') ?>
            <input type='image' alt='����No1235 MC20' height='65' width='65' border='0' src='../img/1235.jpg' onClick='win_open("../img/1235L.jpg","����No1235 MC20")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1257') ?>
            <input type='image' alt='����No1257 NTX-1' height='65' width='65' border='0' src='../img/1257.jpg' onClick='win_open("../img/1257L.jpg","����No1257 NTX-1")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            ��������<BR>MC
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            SL-15
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            ��Ω<BR>MC
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1228') ?>
            <input type='image' alt='����No1228 WT-300' height='65' width='65' border='0' src='../img/1228.jpg' onClick='win_open("../img/1228L.jpg","����No1228 WT-300")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1226') ?>
            <input type='image' alt='����No1226 �ޥ��å�' height='65' width='65' border='0' src='../img/1226.jpg' onClick='win_open("../img/1226L.jpg","����No1226 �ޥ��å�")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1229') ?>
            <input type='image' alt='����No1229 BNE' height='65' width='65' border='0' src='../img/1229.jpg' onClick='win_open("../img/1229L.jpg","����No1229 BNE")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1258') ?>
            <input type='image' alt='����No1258 BS-18' height='65' width='65' border='0' src='../img/1258.jpg' onClick='win_open("../img/1258L.jpg","����No1258 BS-18")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1225') ?>
            <input type='image' alt='����No1225 WT-150' height='65' width='65' border='0' src='../img/1225.jpg' onClick='win_open("../img/1225L.jpg","����No1225 WT-150")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1227') ?>
            <input type='image' alt='����No1227 WT-150S' height='65' width='65' border='0' src='../img/1227.jpg' onClick='win_open("../img/1227L.jpg","����No1227 WT-150S")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1224') ?>
            <input type='image' alt='����No1224 TW-10' height='65' width='65' border='0' src='../img/1224.jpg' onClick='win_open("../img/1224L.jpg","����No1224 TW-10")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1259') ?>
            <input type='image' alt='����No1259 NTX-2' height='65' width='65' border='0' src='../img/1259.jpg' onClick='win_open("../img/1259L.jpg","����No1259 NTX-2")'>
        </td>
    </tr>
    <tr>
    </tr>
    <tr>
        <td bgcolor='#f0f0f0'><b>��<BR>��<BR>��<BR>��<BR>��</b></td>
    </tr>
    <tr>
        <td rowspan='3'></td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            �ų���<BR>�־�
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            2��<BR>�ù�
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1349') ?>
            <input type='image' alt='����No1349 WTS' height='65' width='65' border='0' src='../img/1349.jpg' onClick='win_open("../img/1349L.jpg","����No1349 WTS")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1365') ?>
            <input type='image' alt='����No1365 WT-1' height='65' width='65' border='0' src='../img/1365.jpg' onClick='win_open("../img/1365L.jpg","����No1365 WT-1")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1366') ?>
            <input type='image' alt='����No1366 WT-2' height='65' width='65' border='0' src='../img/1366.jpg' onClick='win_open("../img/1366L.jpg","����No1366 WT-2")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1348') ?>
            <input type='image' alt='����No1348 BNF-2' height='65' width='65' border='0' src='../img/1348.jpg' onClick='win_open("../img/1348L.jpg","����No1348 BNF-2")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1347') ?>
            <input type='image' alt='����No1347 BNF-1' height='65' width='65' border='0' src='../img/1347.jpg' onClick='win_open("../img/1347L.jpg","����No1347 BNF-1")'>
        </td>
        <td colspan='1'></td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1364') ?>
            <input type='image' alt='����No1364 BND-4' height='65' width='65' border='0' src='../img/1364.jpg' onClick='win_open("../img/1364L.jpg","����No1364 BND-4")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1346') ?>
            <input type='image' alt='����No1346 BNE-1' height='65' width='65' border='0' src='../img/1346.jpg' onClick='win_open("../img/1346L.jpg","����No1346 BNE-1")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1367') ?>
            <input type='image' alt='����No1367 ���ގ�-1' height='65' width='65' border='0' src='../img/1367.jpg' onClick='win_open("../img/1367L.jpg","����No1367 ���ގ�-1")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1369') ?>
            <input type='image' alt='����No1369 L20' height='65' width='65' border='0' src='../img/1369.jpg' onClick='win_open("../img/1369L.jpg","����No1369 L20")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1373') ?>
            <input type='image' alt='����No1373 L32' height='65' width='65' border='0' src='../img/1373.jpg' onClick='win_open("../img/1373L.jpg","����No1373 L32")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1374') ?>
            <input type='image' alt='����No1374 BNA' height='65' width='65' border='0' src='../img/1374.jpg' onClick='win_open("../img/1374L.jpg","����No1374 BNA")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1372') ?>
            <input type='image' alt='����No1372 ABX-2' height='65' width='65' border='0' src='../img/1372.jpg' onClick='win_open("../img/1372L.jpg","����No1372 ABX-2")'>
        </td>
        <td bgcolor='#ffffff' rowspan='2' nowrap valign='center' align='center'>
            <?php mac_state_view('1368') ?>
            <input type='image' alt='����No1368 ABX-1' height='65' width='65' border='0' src='../img/1368.jpg' onClick='win_open("../img/1368L.jpg","����No1368 ABX-1")'>
        </td>
    </tr>
    <!--
    <tr>
        <td height='80' colspan='4' bgcolor='#f0f0f0'><center>������</center></td>
    </tr>
    -->
    <tr>
    </tr>
    <tr>
        <td colspan='5'></td>
        <td bgcolor='#f0f0f0'><center><b>������ ��</b></center></td>
        <td colspan='11'></td>
    </tr>
</table>
