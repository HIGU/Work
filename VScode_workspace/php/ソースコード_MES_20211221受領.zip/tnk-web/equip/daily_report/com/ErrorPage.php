<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Language" content="ja">
<meta http-equiv="Content-Type" content="text/html; charset=EUC-JP">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="Expires" content="0">
</head>
<body>
<center>
<table border='0' class='LAYOUT'>
    <tr class='LAYOUT'>
        <td class='LAYOUT' align='center'>
            <font size='5' color='#ff0000'><b>�����ƥ२�顼��ȯ�����ޤ�����</b></font><br>
        </td>
    </tr>
    <tr class='LAYOUT'>
        <td class='LAYOUT'>
            <pre><?=$SYSTEM_MESSAGE?></pre>
        </td>
    </tr>
</table>
</center>
</body>
</html>
